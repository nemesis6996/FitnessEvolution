import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertUserSchema,
  insertExerciseSchema,
  insertWorkoutSchema,
  insertWorkoutExerciseSchema,
  insertProgramSchema,
  insertProgramWorkoutSchema,
  insertUserWorkoutProgressSchema,
  insertUserExerciseProgressSchema,
  insertAiAssistantLogSchema,
  insertBodyScanHistorySchema,
  insertAvatarCustomizationSchema,
} from "@shared/schema";
import { z } from "zod";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import MemoryStore from "memorystore";

// OpenAI integration for AI Assistant
import OpenAI from "openai";

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || "demo-key", // In a real app, this would be properly secured
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure session
  const MemoryStoreSession = MemoryStore(session);
  app.use(
    session({
      secret: "fitpro-secret-key", // In production, use a proper secret
      resave: false,
      saveUninitialized: false,
      cookie: { secure: process.env.NODE_ENV === "production", maxAge: 24 * 60 * 60 * 1000 }, // 24 hours
      store: new MemoryStoreSession({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
    })
  );

  // Initialize Passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Configure Passport.js
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Username non trovato" });
        }
        if (user.password !== password) {
          // In a real app, we would use proper password hashing
          return done(null, false, { message: "Password errata" });
        }
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    })
  );

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Authentication middleware
  const isAuthenticated = (req: Request, res: Response, next: Function) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Non autorizzato" });
  };

  // Authentication routes
  app.post("/api/auth/login", (req, res, next) => {
    passport.authenticate("local", (err: Error, user: any, info: any) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(400).json({ message: info.message });
      }
      req.logIn(user, (err) => {
        if (err) {
          return next(err);
        }
        // Remove password from user object
        const { password, ...userWithoutPassword } = user;
        return res.status(200).json(userWithoutPassword);
      });
    })(req, res, next);
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout(() => {
      res.status(200).json({ message: "Logout effettuato con successo" });
    });
  });

  app.get("/api/auth/user", isAuthenticated, (req, res) => {
    // Remove password from user object
    const { password, ...userWithoutPassword } = req.user as any;
    res.status(200).json(userWithoutPassword);
  });

  app.post("/api/auth/register", async (req, res, next) => {
    try {
      const userData = insertUserSchema.parse(req.body);

      // Check if username already exists
      const existingUserByUsername = await storage.getUserByUsername(userData.username);
      if (existingUserByUsername) {
        return res.status(400).json({ message: "Username già in uso" });
      }

      // Check if email already exists
      const existingUserByEmail = await storage.getUserByEmail(userData.email);
      if (existingUserByEmail) {
        return res.status(400).json({ message: "Email già in uso" });
      }

      // Create user
      const newUser = await storage.createUser(userData);
      
      // Remove password from response
      const { password, ...userWithoutPassword } = newUser;
      
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        next(error);
      }
    }
  });

  // User routes
  app.put("/api/users/:id", isAuthenticated, async (req, res, next) => {
    try {
      const userId = parseInt(req.params.id);
      const currentUser = req.user as any;
      
      // Only allow users to update their own profile
      if (currentUser.id !== userId) {
        return res.status(403).json({ message: "Non autorizzato ad aggiornare questo profilo" });
      }
      
      const userData = req.body;
      const updatedUser = await storage.updateUser(userId, userData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "Utente non trovato" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = updatedUser;
      
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      next(error);
    }
  });

  // Muscle Groups routes
  app.get("/api/muscle-groups", async (req, res, next) => {
    try {
      const muscleGroups = await storage.getAllMuscleGroups();
      res.status(200).json(muscleGroups);
    } catch (error) {
      next(error);
    }
  });

  // Exercises routes
  app.get("/api/exercises", async (req, res, next) => {
    try {
      const exercises = await storage.getAllExercises();
      res.status(200).json(exercises);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/exercises/search", async (req, res, next) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Query parameter 'q' is required" });
      }
      
      const exercises = await storage.searchExercises(query);
      res.status(200).json(exercises);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/exercises/:id", async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const exercise = await storage.getExercise(id);
      
      if (!exercise) {
        return res.status(404).json({ message: "Esercizio non trovato" });
      }
      
      res.status(200).json(exercise);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/muscle-groups/:id/exercises", async (req, res, next) => {
    try {
      const muscleGroupId = parseInt(req.params.id);
      const exercises = await storage.getExercisesByMuscleGroup(muscleGroupId);
      res.status(200).json(exercises);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/exercises", isAuthenticated, async (req, res, next) => {
    try {
      const exerciseData = insertExerciseSchema.parse(req.body);
      const newExercise = await storage.createExercise(exerciseData);
      res.status(201).json(newExercise);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        next(error);
      }
    }
  });

  app.put("/api/exercises/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const exerciseData = req.body;
      const updatedExercise = await storage.updateExercise(id, exerciseData);
      
      if (!updatedExercise) {
        return res.status(404).json({ message: "Esercizio non trovato" });
      }
      
      res.status(200).json(updatedExercise);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/exercises/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteExercise(id);
      
      if (!success) {
        return res.status(404).json({ message: "Esercizio non trovato" });
      }
      
      res.status(204).end();
    } catch (error) {
      next(error);
    }
  });

  // Workouts routes
  app.get("/api/workouts", async (req, res, next) => {
    try {
      const workouts = await storage.getAllWorkouts();
      res.status(200).json(workouts);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/workouts/templates", async (req, res, next) => {
    try {
      const templates = await storage.getTemplateWorkouts();
      res.status(200).json(templates);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/workouts/:id", async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const workout = await storage.getWorkout(id);
      
      if (!workout) {
        return res.status(404).json({ message: "Allenamento non trovato" });
      }
      
      res.status(200).json(workout);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/workouts/:id/exercises", async (req, res, next) => {
    try {
      const workoutId = parseInt(req.params.id);
      const workoutExercises = await storage.getWorkoutExercises(workoutId);
      
      // Get exercise details for each workout exercise
      const exercises = await Promise.all(
        workoutExercises.map(async (we) => {
          const exercise = await storage.getExercise(we.exerciseId);
          return {
            ...we,
            exercise,
          };
        })
      );
      
      res.status(200).json(exercises);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/workouts", isAuthenticated, async (req, res, next) => {
    try {
      const workoutData = insertWorkoutSchema.parse(req.body);
      const newWorkout = await storage.createWorkout(workoutData);
      res.status(201).json(newWorkout);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        next(error);
      }
    }
  });

  app.put("/api/workouts/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const workoutData = req.body;
      const updatedWorkout = await storage.updateWorkout(id, workoutData);
      
      if (!updatedWorkout) {
        return res.status(404).json({ message: "Allenamento non trovato" });
      }
      
      res.status(200).json(updatedWorkout);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/workouts/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteWorkout(id);
      
      if (!success) {
        return res.status(404).json({ message: "Allenamento non trovato" });
      }
      
      res.status(204).end();
    } catch (error) {
      next(error);
    }
  });

  // Workout Exercises routes
  app.post("/api/workout-exercises", isAuthenticated, async (req, res, next) => {
    try {
      const workoutExerciseData = insertWorkoutExerciseSchema.parse(req.body);
      const newWorkoutExercise = await storage.addExerciseToWorkout(workoutExerciseData);
      res.status(201).json(newWorkoutExercise);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        next(error);
      }
    }
  });

  app.put("/api/workout-exercises/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const workoutExerciseData = req.body;
      const updatedWorkoutExercise = await storage.updateWorkoutExercise(id, workoutExerciseData);
      
      if (!updatedWorkoutExercise) {
        return res.status(404).json({ message: "Esercizio dell'allenamento non trovato" });
      }
      
      res.status(200).json(updatedWorkoutExercise);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/workout-exercises/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.removeExerciseFromWorkout(id);
      
      if (!success) {
        return res.status(404).json({ message: "Esercizio dell'allenamento non trovato" });
      }
      
      res.status(204).end();
    } catch (error) {
      next(error);
    }
  });

  // Programs routes
  app.get("/api/programs", async (req, res, next) => {
    try {
      const programs = await storage.getAllPrograms();
      res.status(200).json(programs);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/programs/templates", async (req, res, next) => {
    try {
      const templates = await storage.getTemplatePrograms();
      res.status(200).json(templates);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/programs/:id", async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const program = await storage.getProgram(id);
      
      if (!program) {
        return res.status(404).json({ message: "Programma non trovato" });
      }
      
      res.status(200).json(program);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/programs/:id/workouts", async (req, res, next) => {
    try {
      const programId = parseInt(req.params.id);
      const programWorkouts = await storage.getProgramWorkouts(programId);
      
      // Get workout details for each program workout
      const workouts = await Promise.all(
        programWorkouts.map(async (pw) => {
          const workout = await storage.getWorkout(pw.workoutId);
          return {
            ...pw,
            workout,
          };
        })
      );
      
      res.status(200).json(workouts);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/programs", isAuthenticated, async (req, res, next) => {
    try {
      const programData = insertProgramSchema.parse(req.body);
      const newProgram = await storage.createProgram(programData);
      res.status(201).json(newProgram);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        next(error);
      }
    }
  });

  app.put("/api/programs/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const programData = req.body;
      const updatedProgram = await storage.updateProgram(id, programData);
      
      if (!updatedProgram) {
        return res.status(404).json({ message: "Programma non trovato" });
      }
      
      res.status(200).json(updatedProgram);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/programs/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteProgram(id);
      
      if (!success) {
        return res.status(404).json({ message: "Programma non trovato" });
      }
      
      res.status(204).end();
    } catch (error) {
      next(error);
    }
  });

  // Program Workouts routes
  app.post("/api/program-workouts", isAuthenticated, async (req, res, next) => {
    try {
      const programWorkoutData = insertProgramWorkoutSchema.parse(req.body);
      const newProgramWorkout = await storage.addWorkoutToProgram(programWorkoutData);
      res.status(201).json(newProgramWorkout);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        next(error);
      }
    }
  });

  app.put("/api/program-workouts/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const programWorkoutData = req.body;
      const updatedProgramWorkout = await storage.updateProgramWorkout(id, programWorkoutData);
      
      if (!updatedProgramWorkout) {
        return res.status(404).json({ message: "Allenamento del programma non trovato" });
      }
      
      res.status(200).json(updatedProgramWorkout);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/program-workouts/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.removeWorkoutFromProgram(id);
      
      if (!success) {
        return res.status(404).json({ message: "Allenamento del programma non trovato" });
      }
      
      res.status(204).end();
    } catch (error) {
      next(error);
    }
  });

  // User progress routes
  app.get("/api/user-progress", isAuthenticated, async (req, res, next) => {
    try {
      const user = req.user as any;
      const progress = await storage.getUserWorkoutProgress(user.id);
      res.status(200).json(progress);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/user-progress/workouts", isAuthenticated, async (req, res, next) => {
    try {
      const user = req.user as any;
      const progressData = insertUserWorkoutProgressSchema.parse({
        ...req.body,
        userId: user.id,
      });
      const newProgress = await storage.recordWorkoutCompletion(progressData);
      res.status(201).json(newProgress);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        next(error);
      }
    }
  });

  app.post("/api/user-progress/exercises", isAuthenticated, async (req, res, next) => {
    try {
      const user = req.user as any;
      const progressData = insertUserExerciseProgressSchema.parse({
        ...req.body,
        userId: user.id,
      });
      const newProgress = await storage.recordExerciseCompletion(progressData);
      res.status(201).json(newProgress);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        next(error);
      }
    }
  });

  // AI Assistant routes
  app.get("/api/ai/suggestions", isAuthenticated, async (req, res, next) => {
    try {
      const user = req.user as any;
      let suggestion = await storage.getLatestAiSuggestion(user.id);
      
      // If no suggestions found, generate new ones
      if (!suggestion) {
        const newSuggestions = [
          "Considera di aumentare i pesi nei tuoi squat, sei migliorato costantemente nell'ultimo mese.",
          "Oggi è un buon giorno per concentrarti sulla parte superiore dopo i 2 allenamenti delle gambe questa settimana.",
          "Hai lavorato duramente! Una sessione di stretching potrebbe aiutarti nel recupero muscolare."
        ];
        
        suggestion = await storage.saveAiSuggestion({
          userId: user.id,
          suggestions: newSuggestions,
        });
      }
      
      res.status(200).json(suggestion);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/ai/refresh-suggestions", isAuthenticated, async (req, res, next) => {
    try {
      const user = req.user as any;
      
      // Here we would normally generate AI suggestions based on user progress
      // For demo purposes, we're using static suggestions
      const newSuggestions = [
        "Prova ad aggiungere esercizi di plank al tuo programma per migliorare la stabilità core.",
        "Hai già completato 3 allenamenti questa settimana, ottimo lavoro!",
        "Per i tuoi obiettivi, considera di aumentare gradualmente il peso nei tuoi deadlift."
      ];
      
      const suggestion = await storage.saveAiSuggestion({
        userId: user.id,
        suggestions: newSuggestions,
      });
      
      res.status(200).json(suggestion);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/ai/ask", isAuthenticated, async (req, res, next) => {
    try {
      const user = req.user as any;
      const { query } = req.body;
      
      if (!query) {
        return res.status(400).json({ message: "Query is required" });
      }
      
      let response = "";
      
      try {
        // Generate response using OpenAI
        const completion = await openai.chat.completions.create({
          model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          messages: [
            { 
              role: "system", 
              content: "Sei un assistente fitness esperto che aiuta gli utenti con consigli sull'allenamento, l'alimentazione e il benessere generale. Fornisci risposte dettagliate ma concise, supportate da principi scientifici quando appropriato. Evita risposte generiche e cerca di personalizzare i consigli in base alle informazioni disponibili sull'utente." 
            },
            { 
              role: "user", 
              content: query 
            }
          ],
          max_tokens: 500,
        });
        
        response = completion.choices[0].message.content || "Mi dispiace, non sono riuscito a generare una risposta.";
      } catch (error) {
        console.error("OpenAI API error:", error);
        response = "Mi dispiace, si è verificato un errore nel generare una risposta. Per favore riprova più tardi.";
      }
      
      // Log the interaction
      await storage.logAiAssistantInteraction({
        userId: user.id,
        query,
        response,
      });
      
      res.status(200).json({ response });
    } catch (error) {
      next(error);
    }
  });

  // Avatar 3D & Body Scan routes
  app.get("/api/scans/history", isAuthenticated, async (req, res, next) => {
    try {
      const user = req.user as any;
      const scanHistory = await storage.getBodyScanHistory(user.id);
      res.status(200).json(scanHistory);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/scans/save", isAuthenticated, async (req, res, next) => {
    try {
      const user = req.user as any;
      const scanData = insertBodyScanHistorySchema.parse({
        ...req.body,
        userId: user.id
      });
      
      const savedScan = await storage.saveBodyScan(scanData);
      
      // Aggiorna anche i dati utente con le ultime misure
      await storage.updateUser(user.id, {
        bodyMeasurements: scanData.bodyMeasurements,
        avatarLastUpdated: new Date()
      });
      
      res.status(201).json(savedScan);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        next(error);
      }
    }
  });

  app.get("/api/avatar/customizations", isAuthenticated, async (req, res, next) => {
    try {
      const user = req.user as any;
      const avatarCustomizations = await storage.getAvatarCustomizations(user.id);
      res.status(200).json(avatarCustomizations);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/avatar/save", isAuthenticated, async (req, res, next) => {
    try {
      const user = req.user as any;
      const avatarData = insertAvatarCustomizationSchema.parse({
        ...req.body,
        userId: user.id
      });
      
      const savedAvatar = await storage.saveAvatarCustomization(avatarData);
      
      // Aggiorna anche avatar utente se isActive è true
      if (avatarData.isActive) {
        await storage.updateUser(user.id, {
          avatarData: avatarData.avatarData,
          avatarLastUpdated: new Date()
        });
      }
      
      res.status(201).json(savedAvatar);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        next(error);
      }
    }
  });

  app.post("/api/avatar/generate", isAuthenticated, async (req, res, next) => {
    try {
      const user = req.user as any;
      
      // Genera un avatar 3D utilizzando OpenAI (in un caso reale useremmo un servizio di rendering 3D)
      let avatarData = null;
      let errorMessage = null;
      
      try {
        // In una implementazione reale, qui useremmo un servizio di rendering 3D
        // Per ora generiamo dati di placeholder
        
        // Se abbiamo una chiave OpenAI valida, possiamo usare ChatGPT per generare descrizioni più realistiche
        let avatarDescription = null;
        if (process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY !== "demo-key") {
          const completion = await openai.chat.completions.create({
            model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            messages: [
              {
                role: "system", 
                content: "Sei un assistente che crea descrizioni dettagliate di modelli 3D di persone basandoti sulle loro misure fisiche. Genera un JSON con dettagli tecnici e descrittivi per un modello 3D."
              },
              {
                role: "user",
                content: `Genera un oggetto JSON che rappresenta un avatar 3D per una persona con queste misure: ${JSON.stringify(user.bodyMeasurements || {})}`
              }
            ],
            response_format: { type: "json_object" }
          });
          
          avatarDescription = completion.choices[0].message.content;
          avatarData = JSON.parse(avatarDescription);
        } else {
          // Fallback se non abbiamo una chiave API
          avatarData = {
            modelType: "humanoid",
            version: "1.0",
            height: user.bodyMeasurements?.height || 175,
            weight: user.bodyMeasurements?.weight || 70000,
            bodyType: "athletic",
            measurements: user.bodyMeasurements || {},
            renderSettings: {
              quality: "high",
              format: "glb"
            }
          };
        }
        
        // Salva nel database
        await storage.updateUser(user.id, {
          avatarData,
          avatarLastUpdated: new Date()
        });
        
      } catch (error) {
        console.error("Avatar generation error:", error);
        errorMessage = "Errore nella generazione dell'avatar 3D";
      }
      
      if (errorMessage) {
        return res.status(500).json({ error: errorMessage });
      }
      
      res.status(200).json({ avatarData });
    } catch (error) {
      next(error);
    }
  });
  
  // Endpoint per generare un avatar 3D da foto multiple
  app.post("/api/avatar/generate-from-photos", isAuthenticated, async (req, res, next) => {
    try {
      const user = req.user as any;
      
      // Questa implementazione simula il processo. In un'app reale:
      // 1. Utilizza multer o simili per gestire l'upload di file multipart/form-data
      // 2. Elabora le immagini con un servizio di computer vision (es. OpenAI API)
      // 3. Usa gli insight per generare un modello 3D preciso
      
      // Simuliamo l'analisi delle foto con OpenAI Vision API
      // Nota: In produzione, dovresti convertire i file in base64 per l'invio all'API
      let avatarData = null;
      let bodyMeasurements = null;
      
      try {
        if (process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY !== "demo-key") {
          // Simula analisi con OpenAI (nota: qui non stiamo veramente usando le foto)
          // In un'implementazione reale, convertirai le immagini in base64 e le invierai all'API
          const mockPhotosAnalysis = await openai.chat.completions.create({
            model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            messages: [
              {
                role: "system", 
                content: "Sei un sistema avanzato di analisi corporea che elabora immagini per generare misurazioni corporee precise e dati per un avatar 3D. Crea un JSON con misurazioni dettagliate e proprietà dell'avatar."
              },
              {
                role: "user",
                content: `Simula l'analisi di tre foto (frontale, posteriore e laterale) di un utente e genera dati dettagliati per un avatar 3D e misurazioni corporee. Fornisci un JSON completo con dimensioni e parametri medi realistici.`
              }
            ],
            response_format: { type: "json_object" }
          });
          
          // Elabora il risultato dell'analisi
          const analysisResult = JSON.parse(mockPhotosAnalysis.choices[0].message.content);
          
          // Estrai i dati necessari
          avatarData = {
            modelType: "humanoid",
            version: "2.0",
            bodyType: analysisResult.bodyType || "mesomorph",
            height: analysisResult.height || 175,
            weight: analysisResult.weight || 70000,
            gender: analysisResult.gender || "unspecified",
            muscleDefinition: analysisResult.muscleDefinition || "medium",
            bodyFatPercentage: analysisResult.bodyFatPercentage || 15,
            posture: analysisResult.posture || "neutral",
            proportions: analysisResult.proportions || { balanced: true },
            renderSettings: {
              quality: "ultra",
              format: "glb",
              textureResolution: "2k"
            },
            measurements: analysisResult.measurements || {
              chest: 98,
              waist: 81,
              hips: 96,
              biceps: 35,
              thighs: 57
            }
          };
          
          // Estrai le misurazioni per l'utente
          bodyMeasurements = {
            height: analysisResult.height || 175,
            weight: analysisResult.weight || 70000,
            chest: analysisResult.measurements?.chest || 98,
            waist: analysisResult.measurements?.waist || 81,
            hips: analysisResult.measurements?.hips || 96,
            biceps: analysisResult.measurements?.biceps || 35,
            thighs: analysisResult.measurements?.thighs || 57
          };
        } else {
          // Fallback se non abbiamo una chiave API valida
          avatarData = {
            modelType: "humanoid",
            version: "2.0",
            bodyType: "mesomorph",
            height: 175,
            weight: 70000,
            muscleDefinition: "medium",
            bodyFatPercentage: 15,
            renderSettings: {
              quality: "high",
              format: "glb"
            },
            measurements: {
              chest: 98,
              waist: 81,
              hips: 96,
              biceps: 35,
              thighs: 57
            }
          };
          
          bodyMeasurements = {
            height: 175,
            weight: 70000,
            chest: 98,
            waist: 81,
            hips: 96,
            biceps: 35,
            thighs: 57
          };
        }
        
        // Salva l'avatar e le misurazioni nel database
        await storage.updateUser(user.id, {
          avatarData,
          bodyMeasurements,
          avatarLastUpdated: new Date()
        });
        
      } catch (error) {
        console.error("Photo analysis error:", error);
        return res.status(500).json({ error: "Errore nell'analisi delle foto" });
      }
      
      // Restituisci i dati dell'avatar e le misurazioni generate
      res.status(200).json({ 
        avatarData,
        bodyMeasurements
      });
    } catch (error) {
      next(error);
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);
  
  // Endpoint per le notifiche push (polling) come alternativa a WebSocket
  app.get("/api/notifications", isAuthenticated, async (req, res, next) => {
    try {
      const userId = (req.user as any).id;
      
      // Definiamo qui notifiche hardcoded per evitare import circolari
      // Queste sono copie delle notifiche definite in client/src/data/sassy-notifications.ts
      const sassyNotifications = [
        // ALLENAMENTI MANCATI
        {
          id: 1,
          type: 'missed_workout',
          severity: 'light',
          title: "Hey, dove sei finito?",
          message: "Il tuo materassino sta piangendo di solitudine. Torni in palestra o dobbiamo venire a prenderti?"
        },
        {
          id: 2,
          type: 'missed_workout',
          severity: 'medium',
          title: "Allenamento? Chi è costui?",
          message: "Il tuo corpo sta dimenticando come si fa a sudare. Quella poltrona ti sta mangiando il culo, muoviti!"
        },
        {
          id: 3,
          type: 'missed_workout',
          severity: 'harsh',
          title: "SVEGLIA C***O!",
          message: "Sei sparito peggio della tua motivazione! Hai paura del ferro o ti sei perso tra il divano e il frigo?"
        },
        // MOTIVAZIONE
        {
          id: 16,
          type: 'motivation',
          severity: 'light',
          title: "Le scuse non bruciano calorie",
          message: "I muscoli si ottengono con il sudore, non con i pensieri. Muovi quel sedere e inizia a spaccare!"
        },
        {
          id: 17,
          type: 'motivation',
          severity: 'medium',
          title: "Dove diavolo sei?",
          message: "Il tuo corpo ti sta implorando di dargli una forma! L'unico modo per zittirlo è macinare chilometri e sollevare pesi, quindi muoviti!"
        },
        {
          id: 18,
          type: 'motivation',
          severity: 'harsh',
          title: "BASTA CAZZEGGIARE!",
          message: "Il dolore è temporaneo, essere un mollaccione è per sempre! Fai schifo oggi per non fare schifo domani! ALZATI E COMBATTI!"
        }
      ];
      
      // Per ora restituiamo una notifica motivazionale casuale
      // In un'implementazione reale, queste verrebbero generate in base all'attività dell'utente
      const notificationType = Math.random() > 0.5 ? 'missed_workout' : 'motivation';
      const severity = Math.random() > 0.7 ? 'harsh' : Math.random() > 0.4 ? 'medium' : 'light';
      
      // Funzione per ottenere una notifica casuale dal nostro array
      const getNotification = (type, severity) => {
        const filtered = sassyNotifications.filter(n => n.type === type && n.severity === severity);
        if (filtered.length === 0) {
          return sassyNotifications[Math.floor(Math.random() * sassyNotifications.length)];
        }
        return filtered[Math.floor(Math.random() * filtered.length)];
      };
      
      // Otteniamo una notifica del tipo richiesto
      let notification = getNotification(notificationType, severity);
      
      // Aggiungiamo timestamp per renderla dinamica
      notification = {
        ...notification,
        timestamp: new Date()
      };
      
      res.status(200).json(notification);
    } catch (error) {
      next(error);
    }
  });

  return httpServer;
}
