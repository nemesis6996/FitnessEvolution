import {
  users, User, InsertUser,
  muscleGroups, MuscleGroup, InsertMuscleGroup,
  exercises, Exercise, InsertExercise,
  workouts, Workout, InsertWorkout,
  workoutExercises, WorkoutExercise, InsertWorkoutExercise,
  programs, Program, InsertProgram,
  programWorkouts, ProgramWorkout, InsertProgramWorkout,
  userWorkoutProgress, UserWorkoutProgress, InsertUserWorkoutProgress,
  userExerciseProgress, UserExerciseProgress, InsertUserExerciseProgress,
  aiAssistantLogs, AiAssistantLog, InsertAiAssistantLog,
  aiSuggestions, AiSuggestion, InsertAiSuggestion,
  bodyScanHistory, BodyScanHistory, InsertBodyScanHistory,
  avatarCustomization, AvatarCustomization, InsertAvatarCustomization
} from "@shared/schema";

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Muscle Groups
  getAllMuscleGroups(): Promise<MuscleGroup[]>;
  getMuscleGroup(id: number): Promise<MuscleGroup | undefined>;
  createMuscleGroup(muscleGroup: InsertMuscleGroup): Promise<MuscleGroup>;
  
  // Exercises
  getAllExercises(): Promise<Exercise[]>;
  getExercise(id: number): Promise<Exercise | undefined>;
  getExercisesByMuscleGroup(muscleGroupId: number): Promise<Exercise[]>;
  createExercise(exercise: InsertExercise): Promise<Exercise>;
  updateExercise(id: number, exercise: Partial<Exercise>): Promise<Exercise | undefined>;
  deleteExercise(id: number): Promise<boolean>;
  searchExercises(query: string): Promise<Exercise[]>;
  
  // Workouts
  getAllWorkouts(): Promise<Workout[]>;
  getWorkout(id: number): Promise<Workout | undefined>;
  getUserWorkouts(userId: number): Promise<Workout[]>;
  getTemplateWorkouts(): Promise<Workout[]>;
  createWorkout(workout: InsertWorkout): Promise<Workout>;
  updateWorkout(id: number, workout: Partial<Workout>): Promise<Workout | undefined>;
  deleteWorkout(id: number): Promise<boolean>;
  
  // Workout Exercises
  getWorkoutExercises(workoutId: number): Promise<WorkoutExercise[]>;
  addExerciseToWorkout(workoutExercise: InsertWorkoutExercise): Promise<WorkoutExercise>;
  updateWorkoutExercise(id: number, workoutExercise: Partial<WorkoutExercise>): Promise<WorkoutExercise | undefined>;
  removeExerciseFromWorkout(id: number): Promise<boolean>;
  
  // Programs
  getAllPrograms(): Promise<Program[]>;
  getProgram(id: number): Promise<Program | undefined>;
  getUserPrograms(userId: number): Promise<Program[]>;
  getTemplatePrograms(): Promise<Program[]>;
  createProgram(program: InsertProgram): Promise<Program>;
  updateProgram(id: number, program: Partial<Program>): Promise<Program | undefined>;
  deleteProgram(id: number): Promise<boolean>;
  
  // Program Workouts
  getProgramWorkouts(programId: number): Promise<ProgramWorkout[]>;
  addWorkoutToProgram(programWorkout: InsertProgramWorkout): Promise<ProgramWorkout>;
  updateProgramWorkout(id: number, programWorkout: Partial<ProgramWorkout>): Promise<ProgramWorkout | undefined>;
  removeWorkoutFromProgram(id: number): Promise<boolean>;
  
  // User Workout Progress
  getUserWorkoutProgress(userId: number): Promise<UserWorkoutProgress[]>;
  recordWorkoutCompletion(progress: InsertUserWorkoutProgress): Promise<UserWorkoutProgress>;
  
  // User Exercise Progress
  getUserExerciseProgress(userId: number, exerciseId: number): Promise<UserExerciseProgress[]>;
  recordExerciseCompletion(progress: InsertUserExerciseProgress): Promise<UserExerciseProgress>;
  
  // AI Assistant
  logAiAssistantInteraction(log: InsertAiAssistantLog): Promise<AiAssistantLog>;
  getAiAssistantLogs(userId: number): Promise<AiAssistantLog[]>;
  
  // AI Suggestions
  getLatestAiSuggestion(userId: number): Promise<AiSuggestion | undefined>;
  saveAiSuggestion(suggestion: InsertAiSuggestion): Promise<AiSuggestion>;
  
  // Body Scan
  getBodyScanHistory(userId: number): Promise<BodyScanHistory[]>;
  saveBodyScan(scanData: InsertBodyScanHistory): Promise<BodyScanHistory>;
  
  // Avatar
  getAvatarCustomizations(userId: number): Promise<AvatarCustomization[]>;
  saveAvatarCustomization(avatarData: InsertAvatarCustomization): Promise<AvatarCustomization>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private muscleGroups: Map<number, MuscleGroup>;
  private exercises: Map<number, Exercise>;
  private workouts: Map<number, Workout>;
  private workoutExercises: Map<number, WorkoutExercise>;
  private programs: Map<number, Program>;
  private programWorkouts: Map<number, ProgramWorkout>;
  private userWorkoutProgress: Map<number, UserWorkoutProgress>;
  private userExerciseProgress: Map<number, UserExerciseProgress>;
  private aiAssistantLogs: Map<number, AiAssistantLog>;
  private aiSuggestions: Map<number, AiSuggestion>;
  private bodyScanHistory: Map<number, BodyScanHistory>;
  private avatarCustomization: Map<number, AvatarCustomization>;

  private currentUserId: number;
  private currentMuscleGroupId: number;
  private currentExerciseId: number;
  private currentWorkoutId: number;
  private currentWorkoutExerciseId: number;
  private currentProgramId: number;
  private currentProgramWorkoutId: number;
  private currentUserWorkoutProgressId: number;
  private currentUserExerciseProgressId: number;
  private currentAiAssistantLogId: number;
  private currentAiSuggestionId: number;
  private currentBodyScanHistoryId: number;
  private currentAvatarCustomizationId: number;

  constructor() {
    this.users = new Map();
    this.muscleGroups = new Map();
    this.exercises = new Map();
    this.workouts = new Map();
    this.workoutExercises = new Map();
    this.programs = new Map();
    this.programWorkouts = new Map();
    this.userWorkoutProgress = new Map();
    this.userExerciseProgress = new Map();
    this.aiAssistantLogs = new Map();
    this.aiSuggestions = new Map();
    this.bodyScanHistory = new Map();
    this.avatarCustomization = new Map();

    this.currentUserId = 1;
    this.currentMuscleGroupId = 1;
    this.currentExerciseId = 1;
    this.currentWorkoutId = 1;
    this.currentWorkoutExerciseId = 1;
    this.currentProgramId = 1;
    this.currentProgramWorkoutId = 1;
    this.currentUserWorkoutProgressId = 1;
    this.currentUserExerciseProgressId = 1;
    this.currentAiAssistantLogId = 1;
    this.currentAiSuggestionId = 1;
    this.currentBodyScanHistoryId = 1;
    this.currentAvatarCustomizationId = 1;

    // Initialize with some data
    this._initializeData();
  }

  private _initializeData() {
    // Add demo user
    this.createUser({
      username: "demo",
      password: "password",
      email: "demo@example.com",
      name: "Marco Rossi",
      level: "Intermedio",
      profileImage: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80",
      role: "user"
    });

    // Add admin user
    this.createUser({
      username: "admin",
      password: "admin123",
      email: "admin@nemmuscle.com",
      name: "Amministratore",
      level: "Admin",
      profileImage: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80",
      role: "admin"
    });

    // Add initial muscle groups
    const muscleGroups = [
      { name: "Petto" },
      { name: "Schiena" },
      { name: "Gambe" },
      { name: "Braccia" },
      { name: "Spalle" },
      { name: "Addominali" },
      { name: "Glutei" },
    ];
    
    muscleGroups.forEach(mg => this.createMuscleGroup(mg));

    // Add initial exercises
    const exercises = [
      {
        name: "Push-up",
        description: "Esercizio base per il petto e i tricipiti",
        imageUrl: "https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        videoUrl: "",
        difficulty: "Principiante",
        instructions: "1. Posizionati a terra con le mani leggermente più larghe delle spalle.\n2. Mantieni il corpo dritto dalla testa ai piedi.\n3. Abbassati piegando i gomiti fino a quando il petto è vicino al suolo.\n4. Spingi verso l'alto tornando alla posizione di partenza.",
        muscleGroupId: 1,
        equipment: "Corpo libero",
      },
      {
        name: "Squat",
        description: "Esercizio fondamentale per le gambe e i glutei",
        imageUrl: "https://images.unsplash.com/photo-1574680178050-55c6a6a96e0a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        videoUrl: "",
        difficulty: "Principiante",
        instructions: "1. Posizionati con i piedi alla larghezza delle spalle.\n2. Abbassa i fianchi come se stessi per sederti, mantenendo il petto in alto.\n3. Scendi fino a quando le cosce sono parallele al pavimento.\n4. Risali alla posizione di partenza.",
        muscleGroupId: 3,
        equipment: "Corpo libero",
      },
      {
        name: "Deadlift",
        description: "Esercizio completo per schiena e gambe",
        imageUrl: "https://images.unsplash.com/photo-1534258936925-c58bed479fcb?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        videoUrl: "",
        difficulty: "Intermedio",
        instructions: "1. Posizionati davanti al bilanciere con i piedi alla larghezza delle spalle.\n2. Afferra il bilanciere con una presa mista o prona.\n3. Solleva il bilanciere mantenendo la schiena dritta, spingendo con le gambe.\n4. Estendi completamente il corpo, quindi abbassa il bilanciere controllando il movimento.",
        muscleGroupId: 2,
        equipment: "Bilanciere",
      },
    ];
    
    exercises.forEach(ex => this.createExercise(ex));

    // Add initial workouts
    const workouts = [
      {
        name: "Allenamento completo upper body",
        description: "Un allenamento intenso per la parte superiore del corpo che lavora su petto, braccia e spalle",
        imageUrl: "",
        difficulty: "Intermedio",
        duration: 45,
        calories: 320,
        isTemplate: true,
        userId: null,
      },
      {
        name: "Full Body - Zero Equipment",
        description: "Un programma completo di allenamento a corpo libero per tonificare tutto il corpo senza bisogno di attrezzature.",
        imageUrl: "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        difficulty: "Principiante",
        duration: 30,
        calories: 250,
        isTemplate: true,
        userId: null,
      },
    ];
    
    workouts.forEach(wo => this.createWorkout(wo));

    // Add exercises to workouts
    const workoutExercises = [
      {
        workoutId: 1,
        exerciseId: 1,
        sets: 3,
        reps: 12,
        restTime: 60,
        order: 1,
      },
      {
        workoutId: 1,
        exerciseId: 3,
        sets: 3,
        reps: 10,
        restTime: 90,
        order: 2,
      },
      {
        workoutId: 2,
        exerciseId: 1,
        sets: 3,
        reps: 15,
        restTime: 45,
        order: 1,
      },
      {
        workoutId: 2,
        exerciseId: 2,
        sets: 3,
        reps: 15,
        restTime: 45,
        order: 2,
      },
    ];
    
    workoutExercises.forEach(we => this.addExerciseToWorkout(we));

    // Add initial programs
    const programs = [
      {
        name: "Full Body - Zero Equipment",
        description: "Un programma completo di allenamento a corpo libero per tonificare tutto il corpo senza bisogno di attrezzature.",
        imageUrl: "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        duration: 4,
        frequency: 3,
        difficulty: "Principiante",
        isTemplate: true,
        userId: null,
      },
      {
        name: "Core Strength Challenge",
        description: "Potenzia il tuo core con questo programma intensivo di 3 settimane per migliorare stabilità, postura e forza addominale.",
        imageUrl: "https://images.unsplash.com/photo-1550345332-09e3ac987658?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        duration: 3,
        frequency: 4,
        difficulty: "Intermedio",
        isTemplate: true,
        userId: null,
      },
    ];
    
    programs.forEach(prog => this.createProgram(prog));

    // Add workouts to programs
    const programWorkouts = [
      {
        programId: 1,
        workoutId: 2,
        weekNumber: 1,
        dayNumber: 1,
      },
      {
        programId: 1,
        workoutId: 2,
        weekNumber: 1,
        dayNumber: 3,
      },
      {
        programId: 1,
        workoutId: 2,
        weekNumber: 1,
        dayNumber: 5,
      },
    ];
    
    programWorkouts.forEach(pw => this.addWorkoutToProgram(pw));

    // AI Suggestions e dati per l'utente demo (ID: 1)
    // Nota: Questo utente è già stato creato all'inizio della funzione

    // Add AI Suggestions for demo user
    this.saveAiSuggestion({
      userId: 1,
      suggestions: [
        "Considera di aumentare i pesi nei tuoi squat, sei migliorato costantemente nell'ultimo mese.",
        "Oggi è un buon giorno per concentrarti sulla parte superiore dopo i 2 allenamenti delle gambe questa settimana.",
        "Hai lavorato duramente! Una sessione di stretching potrebbe aiutarti nel recupero muscolare."
      ],
    });

    // Add workout progress for demo user
    this.recordWorkoutCompletion({
      userId: 1,
      workoutId: 1,
      durationMinutes: 45,
      caloriesBurned: 320,
      feedback: "Ottimo allenamento!",
      rating: 5,
    });
    
    this.recordWorkoutCompletion({
      userId: 1,
      workoutId: 2,
      durationMinutes: 35,
      caloriesBurned: 280,
      feedback: "Un po' facile, ma efficace",
      rating: 4,
    });

    // Aggiungi dati iniziali per l'avatar 3D e le scansioni corporee per l'utente demo
    const bodyMeasurements = {
      height: 178, // cm
      weight: 75000, // g
      chest: 95, // cm
      waist: 82, // cm
      hips: 98, // cm
      biceps: 34, // cm
      thighs: 58, // cm
      bodyFat: 15 // %
    };

    // Aggiorna i dati dell'utente con le misure corporee
    const user = this.users.get(1);
    if (user) {
      const updatedUser = {
        ...user,
        bodyMeasurements,
        avatarLastUpdated: new Date()
      };
      this.users.set(1, updatedUser);
    }

    // Salva una scansione corporea iniziale
    this.saveBodyScan({
      userId: 1,
      bodyMeasurements,
      notes: "Prima scansione corporea"
    });

    // Salva un avatar customizzato iniziale
    this.saveAvatarCustomization({
      userId: 1,
      avatarData: {
        bodyType: "atletico",
        height: 178,
        muscleTone: "moderato",
        skinTone: "#e8c090",
        hairStyle: "corto",
        hairColor: "#4a2e0b",
        facialFeatures: {
          eyeColor: "marrone",
          faceShape: "ovale"
        }
      },
      name: "Il mio avatar",
      isActive: true
    });
  }

  // User management
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Muscle Groups
  async getAllMuscleGroups(): Promise<MuscleGroup[]> {
    return Array.from(this.muscleGroups.values());
  }

  async getMuscleGroup(id: number): Promise<MuscleGroup | undefined> {
    return this.muscleGroups.get(id);
  }

  async createMuscleGroup(insertMuscleGroup: InsertMuscleGroup): Promise<MuscleGroup> {
    const id = this.currentMuscleGroupId++;
    const muscleGroup: MuscleGroup = { ...insertMuscleGroup, id };
    this.muscleGroups.set(id, muscleGroup);
    return muscleGroup;
  }

  // Exercises
  async getAllExercises(): Promise<Exercise[]> {
    return Array.from(this.exercises.values());
  }

  async getExercise(id: number): Promise<Exercise | undefined> {
    return this.exercises.get(id);
  }

  async getExercisesByMuscleGroup(muscleGroupId: number): Promise<Exercise[]> {
    return Array.from(this.exercises.values()).filter(exercise => exercise.muscleGroupId === muscleGroupId);
  }

  async createExercise(insertExercise: InsertExercise): Promise<Exercise> {
    const id = this.currentExerciseId++;
    const now = new Date();
    const exercise: Exercise = { ...insertExercise, id, createdAt: now };
    this.exercises.set(id, exercise);
    return exercise;
  }

  async updateExercise(id: number, exerciseData: Partial<Exercise>): Promise<Exercise | undefined> {
    const exercise = this.exercises.get(id);
    if (!exercise) return undefined;
    
    const updatedExercise = { ...exercise, ...exerciseData };
    this.exercises.set(id, updatedExercise);
    return updatedExercise;
  }

  async deleteExercise(id: number): Promise<boolean> {
    return this.exercises.delete(id);
  }

  async searchExercises(query: string): Promise<Exercise[]> {
    query = query.toLowerCase();
    return Array.from(this.exercises.values()).filter(exercise => 
      exercise.name.toLowerCase().includes(query) || 
      exercise.description.toLowerCase().includes(query)
    );
  }

  // Workouts
  async getAllWorkouts(): Promise<Workout[]> {
    return Array.from(this.workouts.values());
  }

  async getWorkout(id: number): Promise<Workout | undefined> {
    return this.workouts.get(id);
  }

  async getUserWorkouts(userId: number): Promise<Workout[]> {
    return Array.from(this.workouts.values()).filter(workout => workout.userId === userId);
  }

  async getTemplateWorkouts(): Promise<Workout[]> {
    return Array.from(this.workouts.values()).filter(workout => workout.isTemplate);
  }

  async createWorkout(insertWorkout: InsertWorkout): Promise<Workout> {
    const id = this.currentWorkoutId++;
    const now = new Date();
    const workout: Workout = { ...insertWorkout, id, createdAt: now };
    this.workouts.set(id, workout);
    return workout;
  }

  async updateWorkout(id: number, workoutData: Partial<Workout>): Promise<Workout | undefined> {
    const workout = this.workouts.get(id);
    if (!workout) return undefined;
    
    const updatedWorkout = { ...workout, ...workoutData };
    this.workouts.set(id, updatedWorkout);
    return updatedWorkout;
  }

  async deleteWorkout(id: number): Promise<boolean> {
    return this.workouts.delete(id);
  }

  // Workout Exercises
  async getWorkoutExercises(workoutId: number): Promise<WorkoutExercise[]> {
    return Array.from(this.workoutExercises.values())
      .filter(we => we.workoutId === workoutId)
      .sort((a, b) => a.order - b.order);
  }

  async addExerciseToWorkout(insertWorkoutExercise: InsertWorkoutExercise): Promise<WorkoutExercise> {
    const id = this.currentWorkoutExerciseId++;
    const workoutExercise: WorkoutExercise = { ...insertWorkoutExercise, id };
    this.workoutExercises.set(id, workoutExercise);
    return workoutExercise;
  }

  async updateWorkoutExercise(id: number, workoutExerciseData: Partial<WorkoutExercise>): Promise<WorkoutExercise | undefined> {
    const workoutExercise = this.workoutExercises.get(id);
    if (!workoutExercise) return undefined;
    
    const updatedWorkoutExercise = { ...workoutExercise, ...workoutExerciseData };
    this.workoutExercises.set(id, updatedWorkoutExercise);
    return updatedWorkoutExercise;
  }

  async removeExerciseFromWorkout(id: number): Promise<boolean> {
    return this.workoutExercises.delete(id);
  }

  // Programs
  async getAllPrograms(): Promise<Program[]> {
    return Array.from(this.programs.values());
  }

  async getProgram(id: number): Promise<Program | undefined> {
    return this.programs.get(id);
  }

  async getUserPrograms(userId: number): Promise<Program[]> {
    return Array.from(this.programs.values()).filter(program => program.userId === userId);
  }

  async getTemplatePrograms(): Promise<Program[]> {
    return Array.from(this.programs.values()).filter(program => program.isTemplate);
  }

  async createProgram(insertProgram: InsertProgram): Promise<Program> {
    const id = this.currentProgramId++;
    const now = new Date();
    const program: Program = { ...insertProgram, id, createdAt: now };
    this.programs.set(id, program);
    return program;
  }

  async updateProgram(id: number, programData: Partial<Program>): Promise<Program | undefined> {
    const program = this.programs.get(id);
    if (!program) return undefined;
    
    const updatedProgram = { ...program, ...programData };
    this.programs.set(id, updatedProgram);
    return updatedProgram;
  }

  async deleteProgram(id: number): Promise<boolean> {
    return this.programs.delete(id);
  }

  // Program Workouts
  async getProgramWorkouts(programId: number): Promise<ProgramWorkout[]> {
    return Array.from(this.programWorkouts.values())
      .filter(pw => pw.programId === programId)
      .sort((a, b) => a.weekNumber - b.weekNumber || a.dayNumber - b.dayNumber);
  }

  async addWorkoutToProgram(insertProgramWorkout: InsertProgramWorkout): Promise<ProgramWorkout> {
    const id = this.currentProgramWorkoutId++;
    const programWorkout: ProgramWorkout = { ...insertProgramWorkout, id };
    this.programWorkouts.set(id, programWorkout);
    return programWorkout;
  }

  async updateProgramWorkout(id: number, programWorkoutData: Partial<ProgramWorkout>): Promise<ProgramWorkout | undefined> {
    const programWorkout = this.programWorkouts.get(id);
    if (!programWorkout) return undefined;
    
    const updatedProgramWorkout = { ...programWorkout, ...programWorkoutData };
    this.programWorkouts.set(id, updatedProgramWorkout);
    return updatedProgramWorkout;
  }

  async removeWorkoutFromProgram(id: number): Promise<boolean> {
    return this.programWorkouts.delete(id);
  }

  // User Workout Progress
  async getUserWorkoutProgress(userId: number): Promise<UserWorkoutProgress[]> {
    return Array.from(this.userWorkoutProgress.values())
      .filter(progress => progress.userId === userId)
      .sort((a, b) => b.completedAt.getTime() - a.completedAt.getTime());
  }

  async recordWorkoutCompletion(insertUserWorkoutProgress: InsertUserWorkoutProgress): Promise<UserWorkoutProgress> {
    const id = this.currentUserWorkoutProgressId++;
    const now = new Date();
    const progress: UserWorkoutProgress = { ...insertUserWorkoutProgress, id, completedAt: now };
    this.userWorkoutProgress.set(id, progress);
    return progress;
  }

  // User Exercise Progress
  async getUserExerciseProgress(userId: number, exerciseId: number): Promise<UserExerciseProgress[]> {
    return Array.from(this.userExerciseProgress.values())
      .filter(progress => progress.userId === userId && progress.exerciseId === exerciseId)
      .sort((a, b) => b.completedAt.getTime() - a.completedAt.getTime());
  }

  async recordExerciseCompletion(insertUserExerciseProgress: InsertUserExerciseProgress): Promise<UserExerciseProgress> {
    const id = this.currentUserExerciseProgressId++;
    const now = new Date();
    const progress: UserExerciseProgress = { ...insertUserExerciseProgress, id, completedAt: now };
    this.userExerciseProgress.set(id, progress);
    return progress;
  }

  // AI Assistant
  async logAiAssistantInteraction(insertAiAssistantLog: InsertAiAssistantLog): Promise<AiAssistantLog> {
    const id = this.currentAiAssistantLogId++;
    const now = new Date();
    const log: AiAssistantLog = { ...insertAiAssistantLog, id, timestamp: now };
    this.aiAssistantLogs.set(id, log);
    return log;
  }

  async getAiAssistantLogs(userId: number): Promise<AiAssistantLog[]> {
    return Array.from(this.aiAssistantLogs.values())
      .filter(log => log.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  // AI Suggestions
  async getLatestAiSuggestion(userId: number): Promise<AiSuggestion | undefined> {
    const userSuggestions = Array.from(this.aiSuggestions.values())
      .filter(suggestion => suggestion.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    return userSuggestions.length > 0 ? userSuggestions[0] : undefined;
  }

  async saveAiSuggestion(insertAiSuggestion: InsertAiSuggestion): Promise<AiSuggestion> {
    const id = this.currentAiSuggestionId++;
    const now = new Date();
    const suggestion: AiSuggestion = { ...insertAiSuggestion, id, createdAt: now };
    this.aiSuggestions.set(id, suggestion);
    return suggestion;
  }

  // Body Scan methods
  async getBodyScanHistory(userId: number): Promise<BodyScanHistory[]> {
    return Array.from(this.bodyScanHistory.values())
      .filter(scan => scan.userId === userId)
      .sort((a, b) => {
        const dateA = new Date(a.scanDate || 0).getTime();
        const dateB = new Date(b.scanDate || 0).getTime();
        return dateB - dateA; // Ordine decrescente (più recenti prima)
      });
  }

  async saveBodyScan(insertBodyScanHistory: InsertBodyScanHistory): Promise<BodyScanHistory> {
    const id = this.currentBodyScanHistoryId++;
    const now = new Date();
    
    // Assicurati che tutti i campi necessari siano presenti
    const bodyScan: BodyScanHistory = { 
      id, 
      userId: insertBodyScanHistory.userId,
      bodyMeasurements: insertBodyScanHistory.bodyMeasurements,
      notes: insertBodyScanHistory.notes || null,
      weight: insertBodyScanHistory.weight || null,
      bodyFatPercentage: insertBodyScanHistory.bodyFatPercentage || null,
      musclePercentage: insertBodyScanHistory.musclePercentage || null,
      scanDate: now,
      createdAt: now
    };
    
    this.bodyScanHistory.set(id, bodyScan);
    return bodyScan;
  }

  // Avatar methods
  async getAvatarCustomizations(userId: number): Promise<AvatarCustomization[]> {
    return Array.from(this.avatarCustomization.values())
      .filter(avatar => avatar.userId === userId)
      .sort((a, b) => {
        const dateA = new Date(a.createdAt || 0).getTime();
        const dateB = new Date(b.createdAt || 0).getTime();
        return dateB - dateA; // Ordine decrescente (più recenti prima)
      });
  }

  async saveAvatarCustomization(insertAvatarCustomization: InsertAvatarCustomization): Promise<AvatarCustomization> {
    const id = this.currentAvatarCustomizationId++;
    const now = new Date();
    
    // Se questo avatar è impostato come attivo, disattiva tutti gli altri avatar dell'utente
    if (insertAvatarCustomization.isActive) {
      const customizations = Array.from(this.avatarCustomization.entries());
      for (const [key, avatar] of customizations) {
        if (avatar.userId === insertAvatarCustomization.userId && avatar.isActive) {
          const updatedAvatar = { ...avatar, isActive: false };
          this.avatarCustomization.set(key, updatedAvatar);
        }
      }
    }
    
    // Assicurati che tutti i campi necessari siano presenti
    const avatarCustomization: AvatarCustomization = { 
      id, 
      userId: insertAvatarCustomization.userId,
      name: insertAvatarCustomization.name,
      avatarData: insertAvatarCustomization.avatarData,
      isActive: insertAvatarCustomization.isActive ?? true,
      createdAt: now
    };
    
    this.avatarCustomization.set(id, avatarCustomization);
    return avatarCustomization;
  }
}

export const storage = new MemStorage();
