import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  level: text("level").default("Principiante"),
  profileImage: text("profile_image"),
  avatarData: jsonb("avatar_data"), // Dati avatar 3D
  avatarLastUpdated: timestamp("avatar_last_updated"),
  bodyMeasurements: jsonb("body_measurements"), // Misurazioni corpo da scanner
  createdAt: timestamp("created_at").defaultNow(),
  role: text("role").default("user").notNull(), // 'user' o 'admin'
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  avatarLastUpdated: true,
});

// Exercise categories
export const muscleGroups = pgTable("muscle_groups", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
});

export const insertMuscleGroupSchema = createInsertSchema(muscleGroups).omit({
  id: true,
});

// Exercises table
export const exercises = pgTable("exercises", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  videoUrl: text("video_url"),
  difficulty: text("difficulty").notNull(), // principiante, intermedio, avanzato
  instructions: text("instructions").notNull(),
  muscleGroupId: integer("muscle_group_id").notNull(),
  equipment: text("equipment").notNull(), // corpo libero, pesi, macchine, etc.
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertExerciseSchema = createInsertSchema(exercises).omit({
  id: true,
  createdAt: true,
});

// Workouts table
export const workouts = pgTable("workouts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  difficulty: text("difficulty").notNull(),
  duration: integer("duration").notNull(), // in minutes
  calories: integer("calories").notNull(),
  isTemplate: boolean("is_template").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  userId: integer("user_id"), // null for system templates
});

export const insertWorkoutSchema = createInsertSchema(workouts).omit({
  id: true,
  createdAt: true,
});

// Workout Exercises (junction table)
export const workoutExercises = pgTable("workout_exercises", {
  id: serial("id").primaryKey(),
  workoutId: integer("workout_id").notNull(),
  exerciseId: integer("exercise_id").notNull(),
  sets: integer("sets").notNull(),
  reps: integer("reps").notNull(),
  restTime: integer("rest_time").notNull(), // in seconds
  order: integer("order").notNull(),
});

export const insertWorkoutExerciseSchema = createInsertSchema(workoutExercises).omit({
  id: true,
});

// Programs table
export const programs = pgTable("programs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  duration: integer("duration").notNull(), // in weeks
  frequency: integer("frequency").notNull(), // workouts per week
  difficulty: text("difficulty").notNull(),
  isTemplate: boolean("is_template").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  userId: integer("user_id"), // null for system templates
});

export const insertProgramSchema = createInsertSchema(programs).omit({
  id: true,
  createdAt: true,
});

// Program Workouts (junction table)
export const programWorkouts = pgTable("program_workouts", {
  id: serial("id").primaryKey(),
  programId: integer("program_id").notNull(),
  workoutId: integer("workout_id").notNull(),
  weekNumber: integer("week_number").notNull(),
  dayNumber: integer("day_number").notNull(),
});

export const insertProgramWorkoutSchema = createInsertSchema(programWorkouts).omit({
  id: true,
});

// User Workout Progress
export const userWorkoutProgress = pgTable("user_workout_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  workoutId: integer("workout_id").notNull(),
  completedAt: timestamp("completed_at").defaultNow(),
  durationMinutes: integer("duration_minutes").notNull(),
  caloriesBurned: integer("calories_burned").notNull(),
  feedback: text("feedback"),
  rating: integer("rating"),
});

export const insertUserWorkoutProgressSchema = createInsertSchema(userWorkoutProgress).omit({
  id: true,
  completedAt: true,
});

// User Exercise Progress
export const userExerciseProgress = pgTable("user_exercise_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  exerciseId: integer("exercise_id").notNull(),
  workoutProgressId: integer("workout_progress_id").notNull(),
  sets: integer("sets").notNull(),
  reps: integer("reps").notNull(),
  weight: integer("weight"),
  completedAt: timestamp("completed_at").defaultNow(),
});

export const insertUserExerciseProgressSchema = createInsertSchema(userExerciseProgress).omit({
  id: true,
  completedAt: true,
});

// AI Assistant logs
export const aiAssistantLogs = pgTable("ai_assistant_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  query: text("query").notNull(),
  response: text("response").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertAiAssistantLogSchema = createInsertSchema(aiAssistantLogs).omit({
  id: true,
  timestamp: true,
});

// AI Suggestions
export const aiSuggestions = pgTable("ai_suggestions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  suggestions: jsonb("suggestions").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAiSuggestionSchema = createInsertSchema(aiSuggestions).omit({
  id: true,
  createdAt: true,
});

// Notifiche amministrative
export const adminNotifications = pgTable("admin_notifications", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // 'info', 'warning', 'alert'
  targetUserId: integer("target_user_id"), // null = per tutti gli utenti
  isRead: boolean("is_read").default(false),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow(),
  createdBy: integer("created_by").notNull(), // admin ID
});

export const insertAdminNotificationSchema = createInsertSchema(adminNotifications).omit({
  id: true,
  createdAt: true,
});

// Body Scan History
export const bodyScanHistory = pgTable("body_scan_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  bodyMeasurements: jsonb("body_measurements").notNull(), // Misurazioni corpo
  notes: text("notes"),
  weight: integer("weight"), // Peso in grammi
  bodyFatPercentage: integer("body_fat_percentage"), // Percentuale moltiplicata per 100 (es. 15.5% = 1550)
  musclePercentage: integer("muscle_percentage"), // Percentuale moltiplicata per 100
  scanDate: timestamp("scan_date").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertBodyScanHistorySchema = createInsertSchema(bodyScanHistory).omit({
  id: true,
  scanDate: true,
  createdAt: true,
});

// 3D Avatar Customization
export const avatarCustomization = pgTable("avatar_customization", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  avatarData: jsonb("avatar_data").notNull(), // Dati avatar personalizzato
  name: text("name").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAvatarCustomizationSchema = createInsertSchema(avatarCustomization).omit({
  id: true,
  createdAt: true,
});

// Type definitions
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type MuscleGroup = typeof muscleGroups.$inferSelect;
export type InsertMuscleGroup = z.infer<typeof insertMuscleGroupSchema>;

export type Exercise = typeof exercises.$inferSelect;
export type InsertExercise = z.infer<typeof insertExerciseSchema>;

export type Workout = typeof workouts.$inferSelect;
export type InsertWorkout = z.infer<typeof insertWorkoutSchema>;

export type WorkoutExercise = typeof workoutExercises.$inferSelect;
export type InsertWorkoutExercise = z.infer<typeof insertWorkoutExerciseSchema>;

export type Program = typeof programs.$inferSelect;
export type InsertProgram = z.infer<typeof insertProgramSchema>;

export type ProgramWorkout = typeof programWorkouts.$inferSelect;
export type InsertProgramWorkout = z.infer<typeof insertProgramWorkoutSchema>;

export type UserWorkoutProgress = typeof userWorkoutProgress.$inferSelect;
export type InsertUserWorkoutProgress = z.infer<typeof insertUserWorkoutProgressSchema>;

export type UserExerciseProgress = typeof userExerciseProgress.$inferSelect;
export type InsertUserExerciseProgress = z.infer<typeof insertUserExerciseProgressSchema>;

export type AiAssistantLog = typeof aiAssistantLogs.$inferSelect;
export type InsertAiAssistantLog = z.infer<typeof insertAiAssistantLogSchema>;

export type AiSuggestion = typeof aiSuggestions.$inferSelect;
export type InsertAiSuggestion = z.infer<typeof insertAiSuggestionSchema>;

export type BodyScanHistory = typeof bodyScanHistory.$inferSelect;
export type InsertBodyScanHistory = z.infer<typeof insertBodyScanHistorySchema>;

export type AvatarCustomization = typeof avatarCustomization.$inferSelect;
export type InsertAvatarCustomization = z.infer<typeof insertAvatarCustomizationSchema>;

export type AdminNotification = typeof adminNotifications.$inferSelect;
export type InsertAdminNotification = z.infer<typeof insertAdminNotificationSchema>;
