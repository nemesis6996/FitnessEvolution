import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Provider } from "react-redux";
import { store } from "@/store/store";
import { useEffect } from "react";
import { apiRequest } from "@/lib/queryClient";
import { setUser } from "@/store/user-slice";
import { useToast } from "@/hooks/use-toast";
import SassyNotificationPopup from "@/components/notifications/sassy-notification-popup";
import { initializeWebSocket } from "@/lib/websocket";

// Pages
import Dashboard from "@/pages/dashboard";
import Exercises from "@/pages/exercises";
import Programs from "@/pages/programs";
import Progress from "@/pages/progress";
import Profile from "@/pages/profile";
import AiAssistant from "@/pages/ai-assistant";
import Avatar3D from "@/pages/avatar-3d";
import Login from "@/pages/login";
import Register from "@/pages/register";
import NotFound from "@/pages/not-found";

// Admin Pages
import AdminDashboard from "@/pages/admin/index";

function Router() {
  const [location] = useLocation();
  const { toast } = useToast();

  // Check authentication status
  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Prima verifica se abbiamo già l'utente in localStorage
        const savedUser = localStorage.getItem("nemmuscle_user");
        if (savedUser) {
          console.log("Utente trovato in localStorage");
          store.dispatch(setUser(JSON.parse(savedUser)));
        }
        
        // Poi tenta comunque di ottenere i dati aggiornati dal server
        const res = await fetch("/api/auth/user", {
          credentials: "include",
        });

        if (res.ok) {
          const userData = await res.json();
          console.log("Utente autenticato recuperato dal server:", userData);
          store.dispatch(setUser(userData));
          localStorage.setItem("nemmuscle_user", JSON.stringify(userData));
        } else {
          console.log("Utente non autenticato o sessione scaduta");
        }
      } catch (error) {
        console.error("Authentication check failed:", error);
      }
    };

    checkAuth();
  }, []);

  // Protected route component con fallback su utente in localStorage
  const ProtectedRoute = ({ component: Component, ...rest }: any) => {
    // Ottieni l'utente dallo store Redux
    const user = store.getState().user.user;
    
    // Se l'utente non è presente nello store, controlla anche in localStorage
    if (!user) {
      const savedUser = localStorage.getItem("nemmuscle_user");
      
      if (savedUser) {
        // Se trovato in localStorage, aggiorna lo store Redux
        console.log("Utente trovato in localStorage per route protetta");
        store.dispatch(setUser(JSON.parse(savedUser)));
        return <Component {...rest} />;
      }
      
      // Se l'utente non è autenticato e non siamo già nella pagina di login/registrazione
      if (location !== "/login" && location !== "/register") {
        console.log("Utente non autenticato, reindirizzamento al login");
        window.location.href = "/login";
        return null;
      }
    }
    
    return <Component {...rest} />;
  };

  // Admin middleware
  const AdminRoute = ({ component: Component, ...rest }: any) => {
    const user = store.getState().user.user;
    
    // Verifica se l'utente è admin
    if (!user || user.role !== "admin") {
      toast({
        title: "Accesso negato",
        description: "Non hai i permessi per accedere a questa sezione",
        variant: "destructive"
      });
      
      window.location.href = "/";
      return null;
    }
    
    return <Component {...rest} />;
  };

  return (
    <Switch>
      {/* Public routes */}
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      
      {/* Protected routes */}
      <Route path="/">
        <ProtectedRoute component={Dashboard} />
      </Route>
      <Route path="/exercises">
        <ProtectedRoute component={Exercises} />
      </Route>
      <Route path="/programs">
        <ProtectedRoute component={Programs} />
      </Route>
      <Route path="/progress">
        <ProtectedRoute component={Progress} />
      </Route>
      <Route path="/profile">
        <ProtectedRoute component={Profile} />
      </Route>
      <Route path="/ai-assistant">
        <ProtectedRoute component={AiAssistant} />
      </Route>
      <Route path="/avatar-3d">
        <ProtectedRoute component={Avatar3D} />
      </Route>
      
      {/* Admin routes */}
      <Route path="/admin">
        <ProtectedRoute>
          <AdminRoute component={AdminDashboard} />
        </ProtectedRoute>
      </Route>
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <Provider store={store}>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Router />
          
          {/* Sistema di notifiche provocatorie */}
          <SassyNotificationPopup 
            showRandomInterval={true}
            minInterval={60000} // 1 minuto in dev, potrebbe essere più lungo in produzione
            maxInterval={180000} // 3 minuti
          />
        </TooltipProvider>
      </QueryClientProvider>
    </Provider>
  );
}

export default App;
